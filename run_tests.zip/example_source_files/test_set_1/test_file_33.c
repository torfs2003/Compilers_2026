#include <stdio.h>

int main() {
float f = 9.457889;

&f = 3217 * 54564;
}
