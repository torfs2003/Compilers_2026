#include <stdio.h>

int main() {
float z const = 0.895623;
char const y = 'a';
}
