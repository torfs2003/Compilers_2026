#include <stdio.h>

int main() {


int some_variable;

some_variable = x + 3;
}
