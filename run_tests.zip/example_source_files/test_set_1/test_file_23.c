#include <stdio.h>

int main() {

const int x = 25;
x = 25;
x = -6532;
}
